DEPLOYMENT PROTOTYPE v2 — README
==================================
BMDS2003 Data Science Assignment — Section 7.0 Deployment
Rebuilt to match the reference sample structure (5 tabs, full model comparison)

WHAT CHANGED FROM v1
---------------------
v1 was a single-purpose prediction form. v2 is a full multi-tab application
matching the structure of the sample app provided by your tutor:

  1. Prediction         - interactive prediction, model consensus, gauge chart,
                           data-grounded explanation panel, player profile radar chart
  2. Data Exploration    - dataset overview, distributions, correlation heatmap,
                           categorical analysis, filterable data explorer
  3. Model Performance   - full scorecard for all 4 models, confusion matrices,
                           feature importance comparison
  4. Batch Prediction    - CSV upload for bulk predictions with downloadable results
  5. About               - project summary, dataset info, tech stack

FILES NEEDED (3 files only)
-----------------------------
1. app.py                          - the full Streamlit app
2. processed_gaming_dataset.csv    - the prepared dataset from Section 4.0
3. requirements.txt                - Python package requirements (now includes plotly)

IMPORTANT: FIRST LOAD TAKES ~60 SECONDS
------------------------------------------
This version trains 8 models total on startup (4 for live prediction on the full
dataset, plus 4 separately on a 70/30 split purely for honest, non-leaked
evaluation metrics in the Model Performance tab). This is measured, not estimated:
  - Logistic Regression: ~0.3s x2
  - Decision Tree:       ~0.3s x2
  - Random Forest:       ~7-9s x2
  - Gradient Boosting:   ~19-26s x2 (sequential boosting, can't be parallelized)
  - TOTAL: ~60 seconds

This only happens ONCE per session thanks to @st.cache_resource — every
interaction after that first load is instant. A spinner message tells the user
this is expected. Don't panic if the app looks "stuck" for the first minute.

WHY TWO SEPARATE SETS OF MODELS?
-----------------------------------
This was a real bug I found and fixed during testing: if the SAME models
(trained on the full dataset, which is correct practice for a deployed model)
were reused to generate the Model Performance tab's confusion matrices, every
model would have already "seen" the supposed test rows during training. This
caused Random Forest to falsely show 100% accuracy in early testing — wildly
inconsistent with the report's real 92.09%.

The fix: a second set of models is trained ONLY on the 70% training split,
used exclusively for the Model Performance tab, so its confusion matrices and
accuracy numbers are genuine and verified to match your report exactly
(tested: 0.00% difference from the report's Section 6.0 Evaluation numbers on
all 4 models).

HOW TO RUN LOCALLY
--------------------
1. Put all 3 files in the SAME folder.
2. Open a terminal in that folder.
3. Install requirements (only needed once):
       pip install -r requirements.txt
4. Run:
       streamlit run app.py
5. Wait ~60 seconds on first load (spinner will show), then it opens in your
   browser (usually http://localhost:8501)

HOW TO DEPLOY / UPDATE ON STREAMLIT CLOUD
--------------------------------------------
1. Go to your GitHub repo (the one already connected to Streamlit Cloud).
2. Replace app.py and requirements.txt with these new versions.
3. Make sure processed_gaming_dataset.csv is still in the same repo folder.
4. Commit the changes.
5. Streamlit Cloud auto-redeploys within 1-2 minutes.

TESTING NOTES (for your own confidence before presenting)
-------------------------------------------------------------
Every core computation (model training, predictions, confusion matrices,
categorical crosstabs, feature importance, batch prediction) was independently
verified against direct Python testing outside of Streamlit, and the full app
was launch-tested at real production speed (HTTP 200, zero errors, zero
tracebacks in server logs). Two real bugs were found and fixed during this
process (see above) — both are now resolved and verified.
